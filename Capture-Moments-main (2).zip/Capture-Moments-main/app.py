from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'

# Database setup
def init_db():
    conn = sqlite3.connect('capture_moments.db')
    c = conn.cursor()
    
    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  email TEXT UNIQUE NOT NULL,
                  password TEXT NOT NULL,
                  user_type TEXT DEFAULT 'client',
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    
    # Bookings table
    c.execute('''CREATE TABLE IF NOT EXISTS bookings
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  photographer_id INTEGER,
                  event_type TEXT NOT NULL,
                  event_date DATE NOT NULL,
                  location TEXT NOT NULL,
                  price REAL NOT NULL,
                  status TEXT DEFAULT 'pending',
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (user_id) REFERENCES users (id),
                  FOREIGN KEY (photographer_id) REFERENCES users (id))''')
    
    # Portfolio table
    c.execute('''CREATE TABLE IF NOT EXISTS portfolio
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  photographer_id INTEGER,
                  title TEXT NOT NULL,
                  description TEXT,
                  image_url TEXT,
                  category TEXT,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (photographer_id) REFERENCES users (id))''')
    
    conn.commit()
    conn.close()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = sqlite3.connect('capture_moments.db')
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE username = ?', (username,))
        user = c.fetchone()
        conn.close()
        
        if user and check_password_hash(user[3], password):
            session['user_id'] = user[0]
            session['username'] = user[1]
            session['user_type'] = user[4]
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password!', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        user_type = request.form['user_type']
        
        hashed_password = generate_password_hash(password)
        
        conn = sqlite3.connect('capture_moments.db')
        c = conn.cursor()
        try:
            c.execute('INSERT INTO users (username, email, password, user_type) VALUES (?, ?, ?, ?)',
                     (username, email, hashed_password, user_type))
            conn.commit()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username or email already exists!', 'error')
        finally:
            conn.close()
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = sqlite3.connect('capture_moments.db')
    c = conn.cursor()
    
    if session['user_type'] == 'photographer':
        c.execute('SELECT * FROM bookings WHERE photographer_id = ?', (session['user_id'],))
        bookings = c.fetchall()
        return render_template('photographer_dashboard.html', bookings=bookings)
    else:
        c.execute('SELECT * FROM bookings WHERE user_id = ?', (session['user_id'],))
        bookings = c.fetchall()
        return render_template('client_dashboard.html', bookings=bookings)

@app.route('/portfolio')
def portfolio():
    conn = sqlite3.connect('capture_moments.db')
    c = conn.cursor()
    c.execute('''SELECT p.*, u.username FROM portfolio p 
                 JOIN users u ON p.photographer_id = u.id 
                 ORDER BY p.created_at DESC''')
    portfolio_items = c.fetchall()
    conn.close()
    return render_template('portfolio.html', portfolio_items=portfolio_items)

@app.route('/services')
def services():
    return render_template('services.html')

@app.route('/booking', methods=['GET', 'POST'])
def booking():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        event_type = request.form['event_type']
        event_date = request.form['event_date']
        location = request.form['location']
        
        # Simple pricing logic
        pricing = {
            'wedding': 50000,
            'pre_wedding': 25000,
            'birthday': 15000,
            'corporate': 20000,
            'portrait': 10000
        }
        
        price = pricing.get(event_type, 15000)
        
        conn = sqlite3.connect('capture_moments.db')
        c = conn.cursor()
        c.execute('''INSERT INTO bookings (user_id, event_type, event_date, location, price)
                     VALUES (?, ?, ?, ?, ?)''',
                 (session['user_id'], event_type, event_date, location, price))
        conn.commit()
        conn.close()
        
        flash('Booking request submitted successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('booking.html')

@app.route('/photographers')
def photographers():
    conn = sqlite3.connect('capture_moments.db')
    c = conn.cursor()
    c.execute('SELECT id, username, email FROM users WHERE user_type = "photographer"')
    photographers = c.fetchall()
    conn.close()
    return render_template('photographers.html', photographers=photographers)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)